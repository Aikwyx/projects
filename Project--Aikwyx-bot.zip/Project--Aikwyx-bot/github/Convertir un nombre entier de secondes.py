#Convertir un nombre entier de secondes fourni au départ, en un nombre d'années, de mois, de
#jours, de minutes et de secondes

Nombre = int(input('Temps en secondes ? \n --> '))

def convertisseur(Nombre):
    if Nombre < 60:
        return round(Nombre),"Seconde"
    Minutes = Nombre/60
    if Minutes < 60:
        return round(Nombre),"Seconde",round(Minutes),"Minutes"
    Heures = Minutes/60
    if Heures < 24:
        return round(Nombre),"Seconde",round(Minutes),"Minutes",round(Heures),"Heures"
    Jours = Heures/24
    if Jours < 365:
        return round(Nombre),"Seconde",round(Minutes),"Minutes",round(Heures),"Heures",round(Jours),"Jours"
    Années = Jours/365
    if Années > 100:
        print("Gros t'as abusé dans 100 ans tu seras dead de toute façon")
    else:
        return round(Nombre),"Seconde",round(Minutes),"Minutes",round(Heures),"Heures",round(Jours),"Jours",round(Années),"Années"
print(convertisseur(Nombre))