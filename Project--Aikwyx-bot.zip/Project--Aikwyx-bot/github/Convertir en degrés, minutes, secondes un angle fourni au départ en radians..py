#Convertir en degrés, minutes, secondes un angle fourni au départ en radians.
import math
def Calcul(Entry):
    Resultat = Entry*180/math.pi 
    return Resultat

Entry =  int(input("Radian ? --> "))
print("Le nombre choisi est bien :",Entry,"?")
Reponse = input()
if Reponse == "Oui" or "oui":
    print(Calcul(Entry),"degrès")
elif Reponse == "Non" or "non": 
    print("Here we go again")
else:
    print("Erreur.")
    
    