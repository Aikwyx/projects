import math



nombreEnBaseDix = int(input())

def conversionDixToDeux(b10):
    k = -1
    Chiffre = b10
    while Chiffre>=1:              
        Reste = Chiffre%2
        Chiffre = Chiffre//2
        k = k+1
        print(Reste)
    return 



conversionDixToDeux(nombreEnBaseDix)





