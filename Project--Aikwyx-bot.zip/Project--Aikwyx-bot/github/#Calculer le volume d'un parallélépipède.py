#Calculer le volume d'un parallélépipède rectangle dont sont fournis au départ la largeur, la
#hauteur et la profondeur.


print("   _____        _               _                _                                                     _  _        _               _                   _       ")
print("  / ____|      | |             | |              | |                                                   | || |      | |             (_)                 | |      ")
print(" | |      __ _ | |  ___  _   _ | | __   __ ___  | | _   _  _ __ ___    ___   _ __    __ _  _ __  __ _ | || |  ___ | |  ___  _ __   _  _ __    ___   __| |  ___ ")
print(" | |     / _  || | / __|| | | || | \ \ / // _ \ | || | | ||  _   _ \  / _ \ |  _ \  / _  ||  __|/ _  || || | / _ \| | / _ \|  _ \ | ||  _ \  / _ \ / _  | / _ \ ")
print(" | |____| (_| || || (__ | |_| || |  \ V /| (_) || || |_| || | | | | ||  __/ | |_) || (_| || |  | (_| || || ||  __/| ||  __/| |_) || || |_) ||  __/| (_| ||  __/")
print("  \_____|\__ _||_| \___| \__ _||_|   \_/  \___/ |_| \__,_||_| |_| |_| \___| | .__/  \__,_||_|   \__,_||_||_| \___||_| \___|| .__/ |_|| .__/  \___| \__,_| \___|")
print("                                                                            | |                                            | |       | |                       ")
print("                                                                            |_|                                            |_|       |_|                       ")


largeur = int(input("Largeur \n-> "))
longueur = int(input("Longueur \n-> "))
profondeur = int(input("Profondeur \n-> "))


calcul = largeur*longueur*profondeur
print("Résultats : ",calcul)

