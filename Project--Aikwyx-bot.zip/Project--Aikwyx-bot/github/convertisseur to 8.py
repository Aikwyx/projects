string = input()
binary_converted = ' '.join(map(bin, bytearray(string, "ascii")))
print(binary_converted)