"use strict";

const discord = require('discord.js');
const {TOKEN, PREFIX} = require("./config")
const { readdirSync } = require('fs');
const client = new discord.Client();
const fs = require('ffmpeg-static');
const ytdl = require('ytdl-core')
const queue = new Map();

 // pp de maid : const MAID = client.user.avatarURL({ format: 'png', dynamic: true, size: 1024 })
client.commands = new discord.Collection();

const loadCommands = (dir = "./COMMANDS/") => {
    readdirSync(dir).forEach(dirs => {
        const commands = readdirSync(`${dir}/${dirs}/`).filter(files => files.endsWith(".js"));
        for(const file of commands){
            const getFileName = require(`${dir}/${dirs}/${file}`)
            client.commands.set(getFileName.help.name, getFileName)
            console.log(`Commande : ${getFileName.help.name} opérationnelle.`)
        }; 
    });
};
loadCommands();

client.on('message', message => {
    if(!message.content.startsWith(PREFIX)|| message.author.bot) return;
    const args = message.content.slice(PREFIX.length).split(/ +/);
    const command = args.shift().toLowerCase();

    if(!client.commands.has(command)) return;
    client.commands.get(command).run(client, message, args, queue);
})

client.on('ready', () => {
  console.log(`Connecté en tant que ${client.user.tag}!`);
  client.user.setStatus("dnd") 
  client.user.setActivity(`Yay`); 
});




client.login(TOKEN)