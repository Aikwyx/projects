module.exports.run = (client, message , args, queue) => {
  
const fs = require('ffmpeg-static');
const ytdl = require('ytdl-core')
  if(message.channel.type ==="dm"||message.channel.type==="group")
  {return;}
    const serverQueue = queue.get(message.guild.id);
    function stop(message, serverQueue) {
        if (!message.member.voice.channel || message.member.voice.channel === message.author)
          return message.channel.send(
            "Tu dois être en vocal pour pouvoir __stop__ une musique"
          );
          if (!serverQueue)
          return message.channel.send("Aucune musique présente dans la file.")
        serverQueue.songs = [];
        serverQueue.connection.dispatcher.end();
        message.channel.send(`Passe une bonne journée !`)
      }
    stop(message, serverQueue);
}
module.exports.help = {
    name:"stop",
    description:"stop"
}