module.exports.run = (client, message,args, queue) => {
  
const fs = require('ffmpeg-static');
const ytdl = require('ytdl-core')
  if(message.channel.type ==="dm"||message.channel.type==="group")
  {return;}
    const serverQueue = queue.get(message.guild.id);
    function skip(message, serverQueue) {
        if (!message.member.voice.channel)
          return message.channel.send(
            "Tu dois être en vocal pour __skip__ une musique."
          );
      
        if (!serverQueue)
          return message.channel.send("Aucune musique présente dans la file.");
        serverQueue.connection.dispatcher.end();
    };   
    skip(message, serverQueue);
}

module.exports.help = {
    name:"skip",
    description:"skip"
}