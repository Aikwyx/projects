module.exports.run = (client, message,args) => {

  const discord = require('discord.js');
const serverURL = message.guild.iconURL({ format: 'png', dynamic: true, size: 1024 })
  const embed = new discord.MessageEmbed()
  .setTitle("La carte du café")
  .setAuthor("Commandes de Maid ")
  .setColor('#ffdbc7')
  .setFooter("Portez vous bien ! ")
  .setImage("https://media.discordapp.net/attachments/705499848174206987/759382882145402920/Images-for-Desktop-Wallpaper-Free-Download-Wallpaperxyz.com-12.png?width=796&height=475")
  .setThumbnail(serverURL)
 
  .setTimestamp()
  .addFields({ name: "Musique : ", value: "`.play ` `.skip` `.stop` "})
  .addFields({ name: "Divers :", value: " `.si` `.pp` `.botinfo` `.say` `.ping` `.cookie` `.userinfo`"})
  .addFields({ name: "Modération :",value: "`.ban` `.bi` `.kick` `.purge` `.totalban`"})
  message.channel.send(embed);

}

module.exports.help = {
    name:"help",
    description:"Commande d'aide"
}