const { PREFIX } = require("../../config");

module.exports.run = (client, message, args) => {
    if (!message.guild) return;
    if (message.author.bot) return;
    if (message.content === PREFIX + 'botinfo') {
       message.channel.send("Yep Im botty the botto");
    }
}
 
module.exports.help = {
    name:"botinfo",
    description:"Les infos du bot"
}