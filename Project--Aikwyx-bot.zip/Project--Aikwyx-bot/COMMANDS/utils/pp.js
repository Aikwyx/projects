module.exports.run = (client, message, args) => {
    const discord = require('discord.js')
    if (!message.guild) return;
    if (message.author.bot) return;
    if (message.content.startsWith('.pp')) {
      const user = message.mentions.users.first() || message.author;
      const avatarEmbed = new discord.MessageEmbed()
          .setColor(0x333333)
          .setAuthor("Avatar de: " + user.username)
          .setImage(user.avatarURL({ format: 'png', dynamic: true, size: 1024 }));
      message.channel.send(avatarEmbed);
}
}
module.exports.help = {
    name:"pp",
    description:"un .avatar en gros mdr"
}