module.exports.run = (client, message, args) => {
    
    const discord = require('discord.js');
    let messageArray = message.content.split(" ");
    args = messageArray.slice(1);
  
    if(message.content.startsWith(".bi")){
      if (message.author.bot) return;
    if(message.channel.type==="dm"||message.channel.type==="group") {
      return message.reply('Tu te sens si seul ? Pauvre de toi. . ');
    }
    if(!message.member.hasPermission(["BAN_MEMBERS"], ["ADMINISTRATOR"])) return  message.delete() && message.channel.send("Tu n'as pas la permission de faire cette commande.")
    let BANMEMBER =  message.mentions.members.first() || message.guild.member(message.guild.members.cache.get(args[0]) )
    let reason = args.slice(1).join(" ")
    if(!reason) reason = "Aucune raison donnée."
    let banheu = new discord.MessageEmbed()
    .setTitle(`${message.guild.name} `)
    .setDescription("**Utilisateur banni :**")
    .addField("```ID :"+ args[0] + "```", `Raison : ${reason}`)
    .setTimestamp()
     if(args[0] === message.guild.ownerID) return message.delete() && message.channel.send("Le propriétaire ne peut pas être banni")
     if(args[0] == undefined);
     if(!Number(args[0])) return message.channel.send(".bi <id> <raison>");
  
     if(Number(args[0])){
    let ban = client.users.fetch(args[0])
    .then(users => message.guild.members.ban(users.id)).then(users => console.log(users)).catch(error => {
    if(error.code !== 1844 ) return message.delete() && message.channel.send('**ID INVALIDE**') }
    ).then(error => { if(!error) message.channel.send(banheu)})
    
  }
    } 
}

module.exports.help = {
    name: "bi",
    description: ".bi user.id raison"
}