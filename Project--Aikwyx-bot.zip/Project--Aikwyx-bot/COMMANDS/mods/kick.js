module.exports.run = (client, message) => {
const discord = require('discord.js');
let messageArray = message.content.split(" ");
let args = messageArray.slice(1);
if(message.content.startsWith(".kick")){
if(message.channel.type==="dm"||message.channel.type==="group") {return message.reply('Tu te sens si seul ? Pauvre de toi. . ');}
    if(!message.member.hasPermission(["KICK_MEMBERS"],  ["BAN_MEMBERS"],  ["ADMINISTRATOR"])) return message.channel.send("Tu n'as pas la permission de faire cette commande.")
let kickMember = message.mentions.members.first() //|| message.guild.members.get(args[0])
if(!kickMember) return message.channel.send("Tu n'as donné aucun utilisateur à kick...")
let reason = args.slice(1).join(" ")
if(!reason) reason = "Aucune raison donnée."
if(!message.guild.me.hasPermission(["KICK_MEMBERS"], ["ADMINISTRATOR"])) return message.channel.send("Je n'ai pas la permission de faire ça.")
const kick = new discord.MessageEmbed()
        .setTitle("Utilisateur kick!")
        .setDescription("Un utilisateur a été kick du serveur")
        .addField(`Le membre a bien été kick pour la raison: ${reason}`, "(logs envoyé dans le salon)")
        .setFooter("Non mais aussi si il fait des bêtises...")
        message.channel.send(kick)
const msgKick = new discord.MessageEmbed()
        .setTitle(`Tu as été kick du serveur ${message.guild.name}!`)
        .setDescription("Tu as fait une bêtise et un modérateur t'as kick..")
        .addField(`${message.member.user.tag} t'as kick pour la raison suivante: ${reason}`, "Fais plus attention !")
    kickMember.send(msgKick).then(() =>
    kickMember.kick()).catch(err => console.log(err))
}}
module.exports.help = {
    name: "kick",
    description: "commande de kick"
}