const { PREFIX } = require("../../config");

module.exports.run = (client , message , args) => {
  if(message.channel.type ==="dm"||message.channel.type==="group")
  {return;}

if (!message.guild) return;

if (message.content.startsWith(PREFIX + "purge")) { 
    message.delete()
  if(!message.member.hasPermission(["KICK_MEMBERS"],  ["BAN_MEMBERS"],  ["ADMINISTRATOR"])) return message.reply("tu n'as pas la permission de faire cette commande.");
  let messageArray = message.content.split(" ");
  let args = messageArray.slice(1);
  const id = args.join()
  let number = id
if(!Number(id)) return message.delete() && message.channel.send("<.purge nombre> :/");
  let limit = 26
  if (id >= limit) {
  number = 25
  message.channel.bulkDelete(number)}
  if (id < limit) {
  message.channel.bulkDelete(number)} 
}


}

module.exports.help = {
    name:"purge",
    description:"C'est un .purge quoi"
}