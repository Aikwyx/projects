const { PREFIX } = require("../../config");
module.exports.run = (client, message, args) => {
    if(message.channel.type ==="dm"||message.channel.type==="group")
    {return;}
if(message.content === PREFIX  + "totalban"){
    message.guild.fetchBans()
    .then(banned => { if(banned.size === 0||null||undefined) return message.channel.send('Aucun membre banni')
    message.channel.send(`${banned.size} users are banned`);    
})
.catch(console.error);
}}

module.exports.help = {
    name:"totalban",
    description:"Affiche le nombre d'utilisateur(s) banni(s) du serveur "
}