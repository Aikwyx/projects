module.exports.run = (client, message) => {
    
    const discord = require('discord.js');
    const user = message.author;
    let messageArray = message.content.split(" ");
    let args = messageArray.slice(1,Infinity)
    let patate = args.join(" ")
    const say = new discord.MessageEmbed() 
    .setColor('#FEE0E2')
    .setFooter(`${user.tag}`)
    .setDescription(patate)
  if(message.content.startsWith(".say")){
    if(message.channel.type ==="dm"||message.channel.type==="group")
    {return;}
      if(patate == '') return;
      if(patate.length >= 1900) return message.delete() && message.channel.send("Vu la taille de ton message tu dois être ennuyant :/")
           message.delete()
         message.channel.send(say)
      }

}

module.exports.help = {
    name:"say",
    description:".say en fait"
}