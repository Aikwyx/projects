module.exports.run = (client, message, args) => {
    if(message.channel.type ==="dm"||message.channel.type==="group")
    {return;}
const discord = require('discord.js')
let messageArray = message.content.split(" ");
args = messageArray.slice(1);
pate = message.mentions.members.first()
if(!pate) {
     user = client.user.username };
if(pate) {
user = message.mentions.members.first().user.username}
const embed = new discord.MessageEmbed()
.setDescription(message.author.username + " donne un cookie à " +  user + "\n 🍪")
.setThumbnail("https://cdn.discordapp.com/attachments/746287554902360134/753880212202061824/cookie.JPG")
message.channel.send(embed)
}
module.exports.help = {
    name:"cookie",
    description:"give a cookie"
}