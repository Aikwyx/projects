exports.TOKEN = "**"
exports.PREFIX = "."